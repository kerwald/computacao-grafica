"use strict";

// =========================================================================
// CONFIGURAÇÃO E CONSTANTES GLOBAIS
// =========================================================================

/**
 * Contém os dados de cada planeta para a simulação, como distância do sol,
 * velocidades e cor da órbita. As unidades de distância são relativas à cena.
 */
const planetData = {
    mercury: { distance: 165,   orbitSpeed: 0.0415,  rotationSpeed: 0.0010, color: [0.7, 0.7, 0.7, 1] },
    venus:   { distance: 308,   orbitSpeed: 0.0162,  rotationSpeed: 0.0008, color: [0.9, 0.6, 0.2, 1] },
    earth:   { distance: 426,   orbitSpeed: 0.0100,  rotationSpeed: 0.0500, color: [0.2, 0.2, 0.8, 1] },
    mars:    { distance: 650,   orbitSpeed: 0.0053,  rotationSpeed: 0.0450, color: [0.8, 0.3, 0.1, 1] },
    jupiter: { distance: 2216,  orbitSpeed: 0.0008,  rotationSpeed: 0.1200, color: [0.8, 0.7, 0.5, 1] },
    saturn:  { distance: 4077,  orbitSpeed: 0.0003,  rotationSpeed: 0.1100, color: [0.9, 0.8, 0.6, 1] },
    uranus:  { distance: 8164,  orbitSpeed: 0.0001,  rotationSpeed: 0.0800, color: [0.6, 0.8, 0.9, 1] },
    neptune: { distance: 12840, orbitSpeed: 0.00006, rotationSpeed: 0.0750, color: [0.3, 0.5, 0.9, 1] }
};


// =========================================================================
// CLASSES PRINCIPAIS
// =========================================================================

/**
 * Representa um nó em um Grafo de Cena (Scene Graph).
 * Um grafo de cena é uma estrutura em árvore que organiza os objetos em uma cena 3D.
 * Cada nó pode ter transformações (escala, rotação, translação) e filhos,
 * permitindo que transformações em um nó pai afetem todos os seus filhos.
 * Isso é útil para criar sistemas complexos como um sistema solar, onde a lua
 * orbita a Terra, que por sua vez orbita o Sol.
 */
var Node = function() {
    this.children = [];       // Nós filhos que herdarão as transformações deste nó.
    this.localMatrix = m4.identity(); // Matriz de transformação local (relativa ao pai).
    this.worldMatrix = m4.identity(); // Matriz de transformação global (relativa ao mundo).
    this.drawInfo = null;     // Informações para desenhar o objeto (buffers, VAO, material).
    this.parent = null;       // Referência ao nó pai.
};

/**
 * Define o pai deste nó, adicionando-o à lista de filhos do pai.
 * @param {Node} parent O novo nó pai.
 */
Node.prototype.setParent = function(parent) {
    // Remove este nó da lista de filhos do pai antigo, se houver.
    if (this.parent) {
        var ndx = this.parent.children.indexOf(this);
        if (ndx >= 0) {
            this.parent.children.splice(ndx, 1);
        }
    }
    // Adiciona este nó à lista de filhos do novo pai.
    if (parent) {
        parent.children.push(this);
    }
    this.parent = parent;
};

/**
 * Atualiza a `worldMatrix` deste nó e de todos os seus filhos, recursivamente.
 * A matriz do mundo de um nó é calculada multiplicando a matriz do mundo de seu pai
 * pela sua própria matriz local.
 * @param {m4.Mat4} [parentWorldMatrix] A matriz do mundo do nó pai.
 */
Node.prototype.updateWorldMatrix = function(parentWorldMatrix) {
    if (parentWorldMatrix) {
        // Se um pai existe, multiplica sua matriz pela local para obter a matriz de mundo deste nó.
        m4.multiply(parentWorldMatrix, this.localMatrix, this.worldMatrix);
    } else {
        // Se não há pai (nó raiz), a matriz de mundo é a mesma que a local.
        m4.copy(this.localMatrix, this.worldMatrix);
    }

    // Propaga a atualização para todos os filhos.
    var worldMatrix = this.worldMatrix;
    this.children.forEach(function(child) {
        child.updateWorldMatrix(worldMatrix);
    });
};


// =========================================================================
// FUNÇÕES DE RENDERIZAÇÃO E WEBGL
// =========================================================================

/**
 * Carrega um modelo 3D a partir de um arquivo .obj e seus materiais .mtl.
 * @param {WebGL2RenderingContext} gl O contexto WebGL2.
 * @param {twgl.ProgramInfo} programInfo As informações do shader program.
 * @param {string} objHref O caminho para o arquivo .obj.
 * @returns {Promise<Array<Object>>} Uma promessa que resolve para um array de "partes" do modelo, cada uma com seu VAO, buffers e material.
 */
async function loadModel(gl, programInfo, objHref) {
    // 1. Carrega e parseia o arquivo .OBJ
    const response = await fetch(objHref);
    if (!response.ok) {
        console.error(`Não foi possível carregar o modelo: ${objHref}`);
        return [];
    }
    const text = await response.text();
    const obj = parseOBJ(text);
    const baseHref = new URL(objHref, window.location.href);

    // 2. Carrega e parseia os arquivos de material (.MTL) referenciados no .OBJ
    const matTexts = await Promise.all(obj.materialLibs.map(async filename => {
        const matHref = new URL(filename, baseHref).href;
        const response = await fetch(matHref);
        return await response.text();
    }));
    const materials = parseMTL(matTexts.join('\n'));

    // 3. Carrega as texturas referenciadas nos materiais
    const textures = {
        defaultWhite: twgl.createTexture(gl, { src: [255, 255, 255, 255] }),
        defaultNormal: twgl.createTexture(gl, { src: [127, 127, 255, 0] }),
    };

    for (const material of Object.values(materials)) {
        // Encontra todas as propriedades que terminam com "Map" (ex: diffuseMap)
        Object.entries(material)
            .filter(([key]) => key.endsWith('Map'))
            .forEach(([key, filename]) => {
                let texture = textures[filename];
                if (!texture) {
                    const textureHref = new URL(filename, baseHref).href;
                    texture = twgl.createTexture(gl, { src: textureHref, flipY: true });
                    textures[filename] = texture;
                }
                material[key] = texture;
            });
    }

    // 4. Material padrão para geometrias que não especificam um.
    const defaultMaterial = {
        diffuse: [1, 1, 1], diffuseMap: textures.defaultWhite,
        normalMap: textures.defaultNormal, ambient: [0, 0, 0],
        specular: [1, 1, 1], specularMap: textures.defaultWhite,
        shininess: 400, opacity: 1,
    };

    // 5. Cria Vertex Array Objects (VAOs) e buffers para cada geometria no arquivo .OBJ
    return obj.geometries.map(({ material, data }) => {
        if (data.position.length === 0) return undefined; // Ignora geometrias vazias

        // Calcula tangentes se houver normais e coordenadas de textura (necessário para normal mapping)
        if (data.texcoord && data.normal) {
            data.tangent = generateTangents(data.position, data.texcoord);
        } else {
            data.tangent = { value: [1, 0, 0] }; // Valor padrão
        }

        // Garante que todos os atributos necessários existam
        if (!data.texcoord) data.texcoord = { value: [0, 0] };
        if (!data.normal) data.normal = { value: [0, 0, 1] };

        // Cria os buffers (VBOs) para os atributos (posição, normais, etc.)
        const bufferInfo = twgl.createBufferInfoFromArrays(gl, data);
        // Cria o VAO, que encapsula a configuração dos atributos e buffers.
        const vao = twgl.createVAOFromBufferInfo(gl, programInfo, bufferInfo);

        return {
            material: { ...defaultMaterial, ...materials[material] },
            bufferInfo,
            vao,
        };
    }).filter(part => part !== undefined); // Remove partes indefinidas
}


// =========================================================================
// FUNÇÃO PRINCIPAL
// =========================================================================

async function main() {
    // --- INICIALIZAÇÃO DO WEBGL ---
    const canvas = document.querySelector("#canvas");
    const gl = canvas.getContext("webgl2");
    if (!gl) {
        alert("Seu navegador não suporta WebGL2. Por favor, tente um navegador moderno como Chrome ou Firefox.");
        return;
    }

    // --- VARIÁVEIS DE CONTROLE DA CÂMERA E INTERAÇÃO ---
    const zoomSpeed = 2.0;
    let cameraAngleX = 0;       // Rotação horizontal da câmera
    let cameraAngleY = 0.2;     // Rotação vertical da câmera
    let cameraDistance = 250;   // Distância da câmera ao alvo
    let isDragging = false;     // Flag para controlar o arrastar do mouse
    let lastMouseX = -1;
    let lastMouseY = -1;
    let cameraTargetNode = null; // O nó que a câmera está seguindo
    let isOverviewMode = true;  // Flag para o modo de visão geral vs. focado em um objeto

    // --- EVENT LISTENERS PARA CONTROLE DA CÂMERA ---
    canvas.addEventListener('mousedown', (event) => {
        isDragging = true;
        lastMouseX = event.clientX;
        lastMouseY = event.clientY;
    });
    canvas.addEventListener('mouseup', () => {
        isDragging = false;
    });
    canvas.addEventListener('mousemove', (event) => {
        if (!isDragging || isOverviewMode) return; // Só rotaciona a câmera se estiver arrastando e não no modo de visão geral
        const deltaX = event.clientX - lastMouseX;
        const deltaY = event.clientY - lastMouseY;
        cameraAngleX += deltaX * 0.005;
        cameraAngleY += deltaY * 0.005;
        // Limita o ângulo vertical para evitar que a câmera "vire de cabeça para baixo"
        cameraAngleY = Math.max(-Math.PI / 2 + 0.1, Math.min(Math.PI / 2 - 0.1, cameraAngleY));
        lastMouseX = event.clientX;
        lastMouseY = event.clientY;
    });
    canvas.addEventListener('wheel', (event) => {
        event.preventDefault(); // Previne o scroll da página
        cameraDistance += event.deltaY * zoomSpeed;
        cameraDistance = Math.max(5, Math.min(30000, cameraDistance)); // Limita o zoom
    });

    twgl.setAttributePrefix("a_");

    // --- SHADERS ---
    // Os shaders são pequenos programas que rodam na GPU.

    // Vertex Shader para as linhas (órbitas e rastros)
    // Apenas transforma a posição dos vértices para o espaço de projeção.
    const vs_line = `#version 300 es
      in vec4 a_position;
      uniform mat4 u_projection;
      uniform mat4 u_view;
      uniform mat4 u_world;

      void main() {
        gl_Position = u_projection * u_view * u_world * a_position;
      }`;

    // Fragment Shader para as linhas
    // Apenas define uma cor sólida uniforme.
    const fs_line = `#version 300 es
      precision highp float;
      uniform vec4 u_color;
      out vec4 outColor;

      void main() {
        outColor = u_color;
      }`;

    // Vertex Shader para os planetas e o sol (modelos 3D)
    // Calcula a posição final do vértice e passa dados (normais, tangentes, etc.) para o Fragment Shader.
    const vs_planet = `#version 300 es
      in vec4 a_position;
      in vec3 a_normal;
      in vec3 a_tangent;
      in vec2 a_texcoord;
      
      uniform mat4 u_projection;
      uniform mat4 u_view;
      uniform mat4 u_world;
      uniform vec3 u_viewWorldPosition; // Posição da câmera no mundo
      
      out vec3 v_normal;
      out vec3 v_tangent;
      out vec3 v_surfaceToView;
      out vec2 v_texcoord;
      
      void main() {
        vec4 worldPosition = u_world * a_position;
        gl_Position = u_projection * u_view * worldPosition;
        v_surfaceToView = u_viewWorldPosition - worldPosition.xyz;
        mat3 normalMat = mat3(u_world); // Matriz para transformar vetores (normais, tangentes)
        v_normal = normalize(normalMat * a_normal);
        v_tangent = normalize(normalMat * a_tangent);
        v_texcoord = a_texcoord;
      }`;

    // Fragment Shader para os planetas e o sol
    // Calcula a cor final de cada píxel com base na iluminação, texturas e materiais.
    const fs_planet = `#version 300 es
      precision highp float;
      // Dados recebidos do Vertex Shader
      in vec3 v_normal;
      in vec3 v_tangent;
      in vec3 v_surfaceToView;
      in vec2 v_texcoord;

      // Uniforms (propriedades do material e da cena)
      uniform vec3 diffuse;
      uniform sampler2D diffuseMap;
      uniform vec3 ambient;
      uniform vec3 emissive;
      uniform vec3 specular;
      uniform sampler2D specularMap;
      uniform float shininess;
      uniform sampler2D normalMap;
      uniform float opacity;
      uniform vec3 u_lightDirection;
      uniform vec3 u_ambientLight;
      
      out vec4 outColor;
      
      void main () {
        vec3 normal = normalize(v_normal);
        vec3 surfaceToViewDirection = normalize(v_surfaceToView);
        vec3 halfVector = normalize(u_lightDirection + surfaceToViewDirection);

        // Modelo de iluminação simplificado (Lambertiano + Phong)
        float fakeLight = dot(u_lightDirection, normal) * .5 + .5;
        float specularLight = clamp(dot(normal, halfVector), 0.0, 1.0);

        vec4 specularMapColor = texture(specularMap, v_texcoord);
        vec3 effectiveSpecular = specular * specularMapColor.rgb;

        vec4 diffuseMapColor = texture(diffuseMap, v_texcoord);
        vec3 effectiveDiffuse = diffuse * diffuseMapColor.rgb;
        float effectiveOpacity = opacity * diffuseMapColor.a;
        
        // Combina as componentes de iluminação para a cor final
        outColor = vec4(
            emissive +                                  // Cor que o objeto emite
            ambient * u_ambientLight +                  // Luz ambiente
            effectiveDiffuse * fakeLight +              // Componente difusa
            effectiveSpecular * pow(specularLight, shininess), // Componente especular
            effectiveOpacity
        );
      }`;

    // Cria os "programas" da GPU, que são a combinação de um Vertex e um Fragment Shader.
    const lineProgramInfo = twgl.createProgramInfo(gl, [vs_line, fs_line]);
    const meshProgramInfo = twgl.createProgramInfo(gl, [vs_planet, fs_planet]);

    // --- CARREGANDO OS MODELOS 3D ---
    // Cada chamada a loadModel retorna um array de "partes" do objeto.
    const sunParts = await loadModel(gl, meshProgramInfo, 'sun/sunR.obj');
    const mercuryParts = await loadModel(gl, meshProgramInfo, 'mercury/mercury.obj');
    const venusParts = await loadModel(gl, meshProgramInfo, 'venus/venus.obj');
    const earthParts = await loadModel(gl, meshProgramInfo, 'earth/earth.obj');
    const moonParts = await loadModel(gl, meshProgramInfo, 'moon/moon.obj');
    const marsParts = await loadModel(gl, meshProgramInfo, 'mars/mars.obj');
    const jupiterParts = await loadModel(gl, meshProgramInfo, 'jupiter/jupiter.obj');
    const saturnParts = await loadModel(gl, meshProgramInfo, 'saturn/saturn.obj');
    const uranusParts = await loadModel(gl, meshProgramInfo, 'uranus/uranus.obj');
    const neptuneParts = await loadModel(gl, meshProgramInfo, 'neptune/neptune.obj');


    // --- CONFIGURANDO O GRAFO DE CENA (SCENE GRAPH) ---
    // A estrutura hierárquica facilita as animações de órbita e rotação.
    // Hierarquia: solarSystem -> orbitNode -> planetNode
    // - solarSystemNode: Raiz da cena.
    // - orbitNode: Gira em torno do sol, carregando o planeta consigo.
    // - planetNode: Gira em seu próprio eixo.

    const solarSystemNode = new Node();
    
    const sunNode = new Node();
    sunNode.drawInfo = sunParts;
    sunNode.setParent(solarSystemNode);
    
    const planetNodes = {};
    for (const [name, data] of Object.entries(planetData)) {
        const orbitNode = new Node();
        orbitNode.localMatrix = m4.translation(data.distance, 0, 0); // Posiciona o centro da órbita
        orbitNode.setParent(solarSystemNode);
        
        const planetNode = new Node(); // O planeta em si
        planetNode.setParent(orbitNode);
        
        planetNodes[name] = { node: planetNode, orbitNode: orbitNode, data: data };
    }
    
    // Atribui os modelos carregados aos nós correspondentes
    planetNodes.mercury.node.drawInfo = mercuryParts;
    planetNodes.venus.node.drawInfo = venusParts;
    planetNodes.earth.node.drawInfo = earthParts;
    planetNodes.mars.node.drawInfo = marsParts;
    planetNodes.jupiter.node.drawInfo = jupiterParts;
    planetNodes.saturn.node.drawInfo = saturnParts;
    planetNodes.uranus.node.drawInfo = uranusParts;
    planetNodes.neptune.node.drawInfo = neptuneParts;

    // A lua é um caso especial: ela orbita a Terra, não o Sol diretamente.
    // Hierarquia: ... -> earthNode -> moonOrbitNode -> moonNode
    const moonOrbitNode = new Node();
    moonOrbitNode.localMatrix = m4.translation(20, 0, 0); // Distância da lua à Terra
    moonOrbitNode.setParent(planetNodes.earth.node);

    const moonNode = new Node();
    moonNode.drawInfo = moonParts;
    moonNode.setParent(moonOrbitNode);
    
    // --- GERAR DADOS DAS ÓRBITAS E RASTROS ---
    const orbitSteps = 400; // Pontos para desenhar o círculo da órbita
    const trailMaxLength = 150; // Comprimento máximo do rastro
    
    const createOrbit = (radius) => {
        const points = [];
        for (let i = 0; i <= orbitSteps; i++) {
            const angle = (i / orbitSteps) * 2 * Math.PI;
            points.push(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
        }
        const bufferInfo = twgl.createBufferInfoFromArrays(gl, { position: points });
        return {
            bufferInfo: bufferInfo,
            vao: twgl.createVAOFromBufferInfo(gl, lineProgramInfo, bufferInfo),
        };
    };

    const orbits = {};
    for (const [name, data] of Object.entries(planetData)) {
        orbits[name] = createOrbit(data.distance);
    }
    const moonOrbit = createOrbit(20); // Órbita da lua em torno da Terra

    // Prepara buffers dinâmicos para os rastros
    const createTrail = () => {
        const bufferInfo = twgl.createBufferInfoFromArrays(gl, { 
            position: { numComponents: 3, data: new Float32Array(trailMaxLength * 3), drawType: gl.DYNAMIC_DRAW }
        });
        const vao = twgl.createVAOFromBufferInfo(gl, lineProgramInfo, bufferInfo);
        return { points: [], bufferInfo, vao };
    };
    const earthTrail = createTrail();
    const moonTrail = createTrail();

    // --- CONTROLES DE TECLADO PARA MUDAR O FOCO DA CÂMERA ---
    cameraTargetNode = solarSystemNode;
    window.addEventListener('keydown', (event) => {
        isOverviewMode = false; // Sai do modo de visão geral ao focar em um objeto
        switch (event.key) {
            case '1': cameraTargetNode = sunNode; cameraDistance = 350; break;
            case '2': cameraTargetNode = planetNodes.mercury.node; cameraDistance = 30; break;
            case '3': cameraTargetNode = planetNodes.venus.node; cameraDistance = 40; break;
            case '4': cameraTargetNode = planetNodes.earth.node; cameraDistance = 50; break;
            case '5': cameraTargetNode = planetNodes.mars.node; cameraDistance = 40; break;
            case '6': cameraTargetNode = planetNodes.jupiter.node; cameraDistance = 150; break;
            case '7': cameraTargetNode = planetNodes.saturn.node; cameraDistance = 120; break;
            case '8': cameraTargetNode = planetNodes.uranus.node; cameraDistance = 100; break;
            case '9': cameraTargetNode = planetNodes.neptune.node; cameraDistance = 100; break;
            case 't': for (const p of Object.values(planetNodes)) {
                            p.data.orbitSpeed = p.data.orbitSpeed + 0.01;
                            p.data.rotationSpeed = p.data.rotationSpeed + 0.05;
                        } break;
            case 'y': for (const p of Object.values(planetNodes)) {
                            p.data.orbitSpeed = p.data.orbitSpeed - 0.01;
                            p.data.rotationSpeed = p.data.rotationSpeed - 0.05;
                        } break;
            case 'm': case 'M': cameraTargetNode = moonNode; cameraDistance = 15; break;
            case '0': 
                cameraTargetNode = solarSystemNode; 
                cameraDistance = 8000; 
                isOverviewMode = true; // Ativa o modo de visão geral
                break;
        }
    });

    const objectsToDraw = [sunNode, moonNode, ...Object.values(planetNodes).map(p => p.node)];
    const fieldOfViewRadians = (d) => d * Math.PI / 180;

    // =========================================================================
    // CICLO DE RENDERIZAÇÃO (DRAW SCENE)
    // =========================================================================
    function drawScene(time) {
        time *= 0.001; // Converte o tempo para segundos

        // 1. PREPARAÇÃO DO CANVAS E ESTADO DO WEBGL
        twgl.resizeCanvasToDisplaySize(gl.canvas);
        gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
        gl.enable(gl.CULL_FACE); // Otimização: não desenha as faces de trás dos objetos
        gl.enable(gl.DEPTH_TEST); // Garante que objetos mais próximos cubram os mais distantes
        gl.clearColor(0, 0, 0, 1); // Fundo preto
        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

        // 2. CÁLCULO DAS MATRIZES DE CÂMERA
        const aspect = gl.canvas.clientWidth / gl.canvas.clientHeight;
        // Matriz de Projeção: Define o "cone de visão" da câmera (perspectiva).
        const projectionMatrix = m4.perspective(fieldOfViewRadians(60), aspect, 0.1, 30000);

        let target, cameraPosition, up;
        if (isOverviewMode) {
            // Câmera fixa para a visão geral do sistema solar
            cameraPosition = [0, 5000, 8000];
            target = [0, 0, 0];
            up = [0, 1, 0];
        } else {
            // Câmera focada em um objeto, controlada pelo mouse
            target = [cameraTargetNode.worldMatrix[12], cameraTargetNode.worldMatrix[13], cameraTargetNode.worldMatrix[14]];
            const cameraMatrixRotation = m4.multiply(m4.xRotation(cameraAngleY), m4.yRotation(cameraAngleX));
            const cameraPositionOffset = m4.transformPoint(cameraMatrixRotation, [0, 0, cameraDistance]);
            cameraPosition = m4.addVectors(target, cameraPositionOffset);
            up = m4.transformPoint(cameraMatrixRotation, [0, 1, 0]);
        }
        
        // Matriz da Câmera: Posiciona e orienta a câmera no mundo.
        const cameraMatrix = m4.lookAt(cameraPosition, target, up);
        // Matriz de Visualização (View): É o inverso da matriz da câmera. Usada para transformar o mundo para o ponto de vista da câmera.
        const viewMatrix = m4.inverse(cameraMatrix);
        
        // 3. ATUALIZAÇÃO DAS ANIMAÇÕES
        // Rotaciona o Sol em seu próprio eixo
        m4.multiply(m4.yRotation(0.005), sunNode.localMatrix, sunNode.localMatrix);
        
        // Atualiza a órbita e a rotação de cada planeta
        for (const p of Object.values(planetNodes)) {
            m4.multiply(m4.yRotation(p.data.orbitSpeed), p.orbitNode.localMatrix, p.orbitNode.localMatrix);
            m4.multiply(m4.yRotation(p.data.rotationSpeed), p.node.localMatrix, p.node.localMatrix);
        }
        
        // Atualiza a órbita e a rotação da Lua
        m4.multiply(m4.yRotation(0.08), moonOrbitNode.localMatrix, moonOrbitNode.localMatrix);
        m4.multiply(m4.yRotation(-0.01), moonNode.localMatrix, moonNode.localMatrix);

        // 4. ATUALIZAÇÃO DO GRAFO DE CENA
        // Calcula a `worldMatrix` final para todos os nós, começando pela raiz.
        solarSystemNode.updateWorldMatrix();

        // 5. ATUALIZAÇÃO DOS RASTROS
        const updateTrail = (trail, node) => {
            const currentPosition = [node.worldMatrix[12], node.worldMatrix[13], node.worldMatrix[14]];
            trail.points.push(...currentPosition);
            if (trail.points.length > trailMaxLength * 3) {
                trail.points.splice(0, 3); // Remove o ponto mais antigo se o rastro estiver muito longo
            }
            // Atualiza o buffer na GPU com os novos pontos, de forma eficiente.
            gl.bindBuffer(gl.ARRAY_BUFFER, trail.bufferInfo.attribs.a_position.buffer);
            gl.bufferSubData(gl.ARRAY_BUFFER, 0, new Float32Array(trail.points));
        };
        updateTrail(earthTrail, planetNodes.earth.node);
        updateTrail(moonTrail, moonNode);

        // 6. DESENHANDO OS MODELOS (SOL E PLANETAS)
        gl.useProgram(meshProgramInfo.program);
        
        // Uniforms compartilhados por todos os objetos
        const sharedUniforms = {
            u_lightDirection: m4.normalize([-1, 3, 5]),
            u_ambientLight: [0.1, 0.1, 0.1],
            u_view: viewMatrix,
            u_projection: projectionMatrix,
            u_viewWorldPosition: cameraPosition,
        };
        twgl.setUniforms(meshProgramInfo, sharedUniforms);

        // Itera e desenha cada objeto
        objectsToDraw.forEach((object) => {
            if (object.drawInfo && object.drawInfo.length > 0) {
                for (const part of object.drawInfo) {
                    gl.bindVertexArray(part.vao); // Ativa o VAO do objeto
                    // Define os uniforms específicos deste objeto (matriz de mundo e material)
                    twgl.setUniforms(meshProgramInfo, { u_world: object.worldMatrix }, part.material);
                    twgl.drawBufferInfo(gl, part.bufferInfo); // Comando de desenho
                }
            }
        });

        // 7. DESENHANDO AS LINHAS (ÓRBITAS E RASTROS)
        gl.useProgram(lineProgramInfo.program);
        twgl.setUniforms(lineProgramInfo, { u_view: viewMatrix, u_projection: projectionMatrix });
        
        // Desenha as órbitas dos planetas
        for (const [name, orbit] of Object.entries(orbits)) {
            twgl.setUniforms(lineProgramInfo, { u_world: m4.identity(), u_color: planetData[name].color });
            gl.bindVertexArray(orbit.vao);
            twgl.drawBufferInfo(gl, orbit.bufferInfo, gl.LINE_LOOP);
        }
        
        // Desenha a órbita da lua (precisa da matriz de mundo da Terra)
        twgl.setUniforms(lineProgramInfo, { u_world: planetNodes.earth.node.worldMatrix, u_color: [0.7, 0.7, 0.7, 1] });
        gl.bindVertexArray(moonOrbit.vao);
        twgl.drawBufferInfo(gl, moonOrbit.bufferInfo, gl.LINE_LOOP);

        // Desenha o rastro da Terra
        twgl.setUniforms(lineProgramInfo, { u_world: m4.identity(), u_color: [0.4, 0.7, 1.0, 1] });
        gl.bindVertexArray(earthTrail.vao);
        twgl.drawBufferInfo(gl, earthTrail.bufferInfo, gl.LINE_STRIP, earthTrail.points.length / 3);

        // Desenha o rastro da Lua
        twgl.setUniforms(lineProgramInfo, { u_world: m4.identity(), u_color: [0.9, 0.9, 0.9, 1] });
        gl.bindVertexArray(moonTrail.vao);
        twgl.drawBufferInfo(gl, moonTrail.bufferInfo, gl.LINE_STRIP, moonTrail.points.length / 3);
        
        // 8. PRÓXIMO FRAME
        // Solicita ao navegador que chame `drawScene` novamente na próxima atualização de tela.
        requestAnimationFrame(drawScene);
    }
    
    // Inicia o ciclo de renderização.
    requestAnimationFrame(drawScene);
}


// =========================================================================
// FUNÇÕES UTILITÁRIAS (PARSERS, ETC.)
// =========================================================================
// Estas funções são helpers para processar os arquivos de modelo e material.
// Geralmente são reutilizadas de exemplos e não precisam de modificação
// para o entendimento da lógica principal da cena.

function parseOBJ(text) {
  const objPositions = [[0, 0, 0]];
  const objTexcoords = [[0, 0]];
  const objNormals = [[0, 0, 0]];
  const objColors = [[0, 0, 0]];
  const objVertexData = [objPositions, objTexcoords, objNormals, objColors];
  let webglVertexData = [[], [], [], []];
  const materialLibs = [];
  const geometries = [];
  let geometry;
  let groups = ['default'];
  let material = 'default';
  let object = 'default';
  const noop = () => {};
  function newGeometry() {
    if (geometry && geometry.data.position.length) {
      geometry = undefined;
    }
  }
  function setGeometry() {
    if (!geometry) {
      const position = [];
      const texcoord = [];
      const normal = [];
      const color = [];
      webglVertexData = [position, texcoord, normal, color];
      geometry = {
        object,
        groups,
        material,
        data: { position, texcoord, normal, color },
      };
      geometries.push(geometry);
    }
  }
  function addVertex(vert) {
    const ptn = vert.split('/');
    ptn.forEach((objIndexStr, i) => {
      if (!objIndexStr) return;
      const objIndex = parseInt(objIndexStr);
      const index = objIndex + (objIndex >= 0 ? 0 : objVertexData[i].length);
      webglVertexData[i].push(...objVertexData[i][index]);
      if (i === 0 && objColors.length > 1) {
        geometry.data.color.push(...objColors[index]);
      }
    });
  }
  const keywords = {
    v(parts) {
      if (parts.length > 3) {
        objPositions.push(parts.slice(0, 3).map(parseFloat));
        objColors.push(parts.slice(3).map(parseFloat));
      } else {
        objPositions.push(parts.map(parseFloat));
      }
    },
    vn(parts) { objNormals.push(parts.map(parseFloat)); },
    vt(parts) { objTexcoords.push(parts.map(parseFloat)); },
    f(parts) {
      setGeometry();
      const numTriangles = parts.length - 2;
      for (let tri = 0; tri < numTriangles; ++tri) {
        addVertex(parts[0]);
        addVertex(parts[tri + 1]);
        addVertex(parts[tri + 2]);
      }
    },
    s: noop,
    mtllib(parts) { materialLibs.push(parts.join(' ')); },
    usemtl(parts, unparsedArgs) {
      material = unparsedArgs;
      newGeometry();
    },
    g(parts) {
      groups = parts;
      newGeometry();
    },
    o(parts, unparsedArgs) {
      object = unparsedArgs;
      newGeometry();
    },
  };
  const keywordRE = /(\w*)(?: )*(.*)/;
  const lines = text.split('\n');
  for (let lineNo = 0; lineNo < lines.length; ++lineNo) {
    const line = lines[lineNo].trim();
    if (line === '' || line.startsWith('#')) continue;
    const m = keywordRE.exec(line);
    if (!m) continue;
    const [, keyword, unparsedArgs] = m;
    const parts = line.split(/\s+/).slice(1);
    const handler = keywords[keyword];
    if (!handler) {
      console.warn('unhandled keyword:', keyword);
      continue;
    }
    handler(parts, unparsedArgs);
  }
  for (const geometry of geometries) {
    geometry.data = Object.fromEntries(
        Object.entries(geometry.data).filter(([, array]) => array.length > 0));
  }
  return { geometries, materialLibs };
}

function parseMTL(text) {
  const materials = {};
  let material;
  const keywords = {
    newmtl(parts, unparsedArgs) {
      material = {};
      materials[unparsedArgs] = material;
    },
    Ns(parts) { material.shininess = parseFloat(parts[0]); },
    Ka(parts) { material.ambient = parts.map(parseFloat); },
    Kd(parts) { material.diffuse = parts.map(parseFloat); },
    Ks(parts) { material.specular = parts.map(parseFloat); },
    Ke(parts) { material.emissive = parts.map(parseFloat); },
    map_Kd(parts, unparsedArgs) { material.diffuseMap = unparsedArgs; },
    map_Ns(parts, unparsedArgs) { material.specularMap = unparsedArgs; },
    map_Bump(parts, unparsedArgs) { material.normalMap = unparsedArgs; },
    Ni(parts) { material.opticalDensity = parseFloat(parts[0]); },
    d(parts) { material.opacity = parseFloat(parts[0]); },
    illum(parts) { material.illum = parseInt(parts[0]); },
  };
  const keywordRE = /(\w*)(?: )*(.*)/;
  const lines = text.split('\n');
  for (let lineNo = 0; lineNo < lines.length; ++lineNo) {
    const line = lines[lineNo].trim();
    if (line === '' || line.startsWith('#')) continue;
    const m = keywordRE.exec(line);
    if (!m) continue;
    const [, keyword, unparsedArgs] = m;
    const parts = line.split(/\s+/).slice(1);
    const handler = keywords[keyword];
    if (!handler) {
      console.warn('unhandled keyword:', keyword);
      continue;
    }
    handler(parts, unparsedArgs);
  }
  return materials;
}

function generateTangents(position, texcoord, indices) {
  const makeIndexIterator = (indices) => {
    let ndx = 0;
    const fn = () => indices[ndx++];
    fn.reset = () => { ndx = 0; };
    fn.numElements = indices.length;
    return fn;
  };
  const makeUnindexedIterator = (positions) => {
    let ndx = 0;
    const fn = () => ndx++;
    fn.reset = () => { ndx = 0; };
    fn.numElements = positions.length / 3;
    return fn;
  };
  const subtractVector2 = (a, b) => a.map((v, ndx) => v - b[ndx]);

  const getNextIndex = indices ? makeIndexIterator(indices) : makeUnindexedIterator(position);
  const numFaceVerts = getNextIndex.numElements;
  const numFaces = numFaceVerts / 3;
  const tangents = [];
  for (let i = 0; i < numFaces; ++i) {
    const n1 = getNextIndex();
    const n2 = getNextIndex();
    const n3 = getNextIndex();
    const p1 = position.slice(n1 * 3, n1 * 3 + 3);
    const p2 = position.slice(n2 * 3, n2 * 3 + 3);
    const p3 = position.slice(n3 * 3, n3 * 3 + 3);
    const uv1 = texcoord.slice(n1 * 2, n1 * 2 + 2);
    const uv2 = texcoord.slice(n2 * 2, n2 * 2 + 2);
    const uv3 = texcoord.slice(n3 * 2, n3 * 2 + 2);
    const dp12 = m4.subtractVectors(p2, p1);
    const dp13 = m4.subtractVectors(p3, p1);
    const duv12 = subtractVector2(uv2, uv1);
    const duv13 = subtractVector2(uv3, uv1);
    const f = 1.0 / (duv12[0] * duv13[1] - duv13[0] * duv12[1]);
    const tangent = Number.isFinite(f)
      ? m4.normalize(m4.scaleVector(m4.subtractVectors(
          m4.scaleVector(dp12, duv13[1]),
          m4.scaleVector(dp13, duv12[1]),
        ), f))
      : [1, 0, 0];
    tangents.push(...tangent, ...tangent, ...tangent);
  }
  return tangents;
}

// Inicia a aplicação.
main();